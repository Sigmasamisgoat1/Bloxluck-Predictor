document.addEventListener('DOMContentLoaded', function () {
    const predictBtn = document.getElementById('predictBtn');
    const resultImg = document.getElementById('resultImg');

    predictBtn.addEventListener('click', function () {
        // Disable the button and show "Calculating"
        predictBtn.disabled = true;
        predictBtn.textContent = "Calculating...";

        // Optional: Hide previous result
        resultImg.classList.add('hidden');

        // Simulate a cooldown (e.g., 5 seconds)
        setTimeout(() => {
            // Your prediction logic here — update image src, etc.
            const prediction = Math.random() < 0.5 ? 'Assets/kirmizi.png' : 'Assets/mavi.png';
            resultImg.src = prediction;
            resultImg.classList.remove('hidden');

            // Re-enable the button
            predictBtn.disabled = false;
            predictBtn.textContent = "Predict";
        }, 5000);
    });
});
